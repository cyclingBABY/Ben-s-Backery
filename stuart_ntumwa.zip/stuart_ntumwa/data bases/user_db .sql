-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 30, 2024 at 06:02 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `user_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `user_form`
--

CREATE TABLE `user_form` (
  `id` int(30) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_type` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_form`
--

INSERT INTO `user_form` (`id`, `name`, `email`, `password`, `user_type`) VALUES
(1, 'swafa', 'swafa@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'admin'),
(2, 'swafa', 'shel@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'admin'),
(3, 'code5_!', 'admin@gmail.com', '21232f297a57a5a743894a0e4a801fc3', 'admin'),
(4, 'Big ben', 'ben@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'user'),
(5, 'swafa', 'swafa1@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'user'),
(6, 'test', 'test@gmail.com', '098f6bcd4621d373cade4e832627b4f6', 'user'),
(7, 'loger', 'loger@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'user'),
(8, 'becky', 'nakibelurebecca@gmail.com', '298eb22a02343a19d72ff528130c380d', 'user'),
(9, 'user', 'user@gmail.com', 'ee11cbb19052e40b07aac0ca060c23ee', 'user'),
(10, 'SHOP', 'SHOP@GMAIL.COM', '827ccb0eea8a706c4c34a16891f84e7b', 'user'),
(12, 'Sendi Iman', 'atom@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'user'),
(13, 'namubiru maluwa', 'daniellamagezi20@gmail.com', 'bd46903ee7b0916961e418204b98a466', 'user'),
(14, 'waswa atibu', 'atom1@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'user'),
(15, 'CONE', 'CONE@GMAIL.COM', 'c55b85dc15b00950104cb1ac870876a5', 'user'),
(16, 'stuart swafa Nt', 'stuartdonsms@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'user'),
(17, 'JESSY', 'jessy@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'user'),
(18, 'Innocent', 'as@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'user'),
(19, 'user', 'user11@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user_form`
--
ALTER TABLE `user_form`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user_form`
--
ALTER TABLE `user_form`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
