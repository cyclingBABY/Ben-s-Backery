-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 30, 2024 at 06:02 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `multi_login`
--

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(200) NOT NULL,
  `FName` varchar(255) NOT NULL,
  `LName` varchar(255) NOT NULL,
  `Tel` varchar(15) NOT NULL,
  `Message` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `FName`, `LName`, `Tel`, `Message`) VALUES
(9, 'stuart', 'Ntumwa', '0781072868', 'furah junior1'),
(10, 'stuart', 'Ntumwa', '0781072868', 'cycling baby'),
(11, 'stuart', 'Ntumwa', '0781072868', 'i love whay you cook'),
(13, 'stuart', 'Ntumwa', '0781072868', 'test1'),
(14, 'stuart', 'Ntumwa', '0781072868', 'hello'),
(15, 'namubiru', 'maluwa', '0701617234', 'cycling baby'),
(16, 'namubiru', 'daniellamagezi20@gmail.com', '0701617234', 'wooooooooooooooooooooooooo');

-- --------------------------------------------------------

--
-- Table structure for table `furstuart`
--

CREATE TABLE `furstuart` (
  `id` int(250) NOT NULL,
  `Fname` varchar(255) NOT NULL,
  `Lname` varchar(255) NOT NULL,
  `Tel` int(255) NOT NULL,
  `Message` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `furstuart`
--

INSERT INTO `furstuart` (`id`, `Fname`, `Lname`, `Tel`, `Message`) VALUES
(1, 'wholemeal', '5000', 701617235, 'cycling baby'),
(2, 'wholemeal', '10000', 712422227, 'hello'),
(3, 'vanilla', '10000', 781072868, 'hello'),
(4, 'stuart4', 'Ntumwa', 781072868, 'cycling baby'),
(5, 'white', '5000', 781072868, 'hello'),
(6, 'test1', 'connection1 22', 781072868, 'cycling baby styles #code5_1'),
(7, 'stuart 22', 'Ntumwa', 781072868, 'halo ha111'),
(8, '', '', 0, ''),
(9, 'stuart', 'Ntumwa', 781072868, 'furah junior1'),
(10, '', '', 0, ''),
(11, '', '', 0, ''),
(12, '', '', 0, ''),
(13, '', '', 0, ''),
(14, '', '', 781072868, 'the orders arrive late '),
(15, '', '', 781072868, 'the orders arrive late '),
(16, '', '', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(200) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `total_price` varchar(255) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `customer_contact` varchar(200) NOT NULL,
  `payment_method` varchar(255) NOT NULL,
  `order_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `product_name`, `total_price`, `customer_name`, `customer_contact`, `payment_method`, `order_date`) VALUES
(1, 'Sambosa', '500.00', 'stuart', '0701617234', 'Cash', '0000-00-00'),
(2, 'Sambosa', '500.00', 'stuart', '0701617234', 'Cash', '0000-00-00'),
(3, 'Sambosa', '500.00', 'stuart', '0701617234', 'Cash', '0000-00-00'),
(4, 'Sambosa', '500.00', 'stuart', '0701617234', 'Cash', '0000-00-00'),
(5, 'Sambosa', '500.00', 'stuart', '0701617234', 'Cash', '0000-00-00'),
(6, 'Sambosa', '500.00', 'stuart', '0701617234', 'Cash', '0000-00-00'),
(7, 'Milk', '1000.00', 'waswa atibu', '07512879', 'Credit Card', '0000-00-00'),
(8, 'Milk', '1000.00', 'waswa atibu', '0701617234', 'Credit Card', '2024-05-10'),
(9, 'Sambosa', '500.00', 'cycling baby', '0775920300', 'Credit Card', '2024-05-11'),
(10, 'Sambosa', '500.00', 'cycling baby', '0775920300', 'Credit Card', '2024-05-11'),
(11, 'Sambosa', '500.00', 'waswa atibu', '0775920300', 'Cash', '2024-05-11'),
(12, 'Milk', '1000.00', 'stuart', '0775920300', 'Credit Card', '2024-05-11'),
(13, 'Milk', '1000.00', 'husna', '0709227793', 'Cash', '2024-05-12'),
(14, 'Milk', '500.00', 'swafa', '0775920300', 'Cash', '2024-05-12'),
(15, 'Milk', '500.00', 'stuart', '0709227793', 'Cash', '2024-05-12'),
(16, 'Coffee cup class', '1000.00', 'baby', '0704902004', 'Cash', '2024-05-12'),
(17, 'family Bread', '5000.00', 'cycling baby', '0775920300', 'Cash', '2024-05-12'),
(18, 'Milk', '1000.00', 'stuart', '0709227793', 'Cash', '2024-05-12'),
(19, 'Sambosa', '500.00', 'hana', '0775920300', 'Cash', '2024-05-14'),
(20, 'family Bread', '5000.00', 'swafa', '0709227793', 'Cash', '2024-05-16'),
(21, 'family Bread', '5000.00', 'swafa', '0709227793', 'Cash', '2024-05-16'),
(22, 'family Bread', '5000.00', 'swafa', '0709227793', 'Cash', '2024-05-16'),
(23, 'Sambosa', '500.00', 'cycling baby', '0704902004', 'Cash', '2024-05-16'),
(24, 'Sambosa', '500.00', 'cycling baby', '0704902004', 'Cash', '2024-05-16'),
(25, 'Sambosa', '5000.00', 'stuart', '0704902004', 'Cash', '2024-05-18'),
(26, 'swafa', '1000000.00', 'swa', '07512879', 'Credit Card', '2024-05-18'),
(27, 'Coffee cup class ', '10000000.00', 'waswa atibu', '0709227793', 'Cash', '2024-05-18'),
(28, 'swadad', '122222.00', 'the sweet face', '0709227793', 'Cash', '2024-05-18'),
(29, 'Beack', '0.50', 'baby', '075107234', 'Cash', '2024-05-20'),
(30, 'Cap cakes', '500.98', 'DASAN', '0704902004', 'Cash', '2024-05-20'),
(31, 'Cristal Bread', '2500.00', 'waswa atibu', '0704902004', 'Cash', '2024-05-23'),
(32, 'Cristal Bread', '2500.00', 'waswa atibu', '0704902004', 'Cash', '2024-05-23'),
(33, 'Cristal Bread', '2500.00', 'waswa atibu', '0704902004', 'Cash', '2024-05-23'),
(34, 'Cap cakes', '500.98', 'waswa atibu', '0701617234', 'Credit Card', '2024-05-24'),
(35, 'Cristal Bread', '2500.00', 'namubiru maluwa', '0701617234', 'Cash', '2024-05-24'),
(36, 'Cap cakes', '500.98', 'waswa atibu', '0701617234', 'Cash', '2024-05-27'),
(37, 'Cap cakes', '500.98', 'user', '0701617234', 'Credit Card', '2024-05-27'),
(38, 'swafa', '3000.00', 'admin', '0775920300', 'Credit Card', '2024-05-27'),
(39, 'amjad', '1000.00', 'admin', '0775920300', 'Credit Card', '2024-05-27'),
(40, 'classic Beaty ', '250000.00', 'admin', '0775920300', 'Credit Card', '2024-05-27'),
(41, 'Milk Tea', '2000.00', 'admin', '0775920300', 'Credit Card', '2024-05-27'),
(42, 'Red yummy Berries', '25000.99', 'admin', '0775920300', 'Credit Card', '2024-05-27'),
(43, 'Milk', '500.00', 'admin', '0775920300', 'Credit Card', '2024-05-27'),
(44, 'Cap cakes', '500.98', 'admin', '0775920300', 'Credit Card', '2024-05-27'),
(45, 'Cristal Bread', '2500.00', 'admin', '0775920300', 'Credit Card', '2024-05-27'),
(46, 'swafa', '3000.00', 'user', '0775920300', 'Credit Card', '2024-05-27'),
(47, 'Milk Tea', '2000.00', 'user', '0775920300', 'Credit Card', '2024-05-27'),
(48, 'Cristal Bread', '2500.00', 'user', '0775920300', 'PayPal', '2024-05-27'),
(49, 'Cap cakes', '500.98', 'user', '0775920300', 'PayPal', '2024-05-27'),
(50, 'Cristal Bread', '2500.00', 'user', '0775920300', 'PayPal', '2024-05-27'),
(51, 'The black cream test', '249999.97', 'user', '0775920300', 'PayPal', '2024-05-27'),
(52, 'Milk', '500.00', 'user', '0775920300', 'PayPal', '2024-05-27'),
(53, 'Milk Tea', '2000.00', 'user', '0775920300', 'PayPal', '2024-05-27'),
(54, 'Red yummy Berries', '25000.99', 'user', '0775920300', 'PayPal', '2024-05-27'),
(55, 'classic Beaty ', '250000.00', 'user', '0775920300', 'PayPal', '2024-05-27'),
(56, 'amjad', '1000.00', 'user', '0775920300', 'PayPal', '2024-05-27'),
(57, 'swafa', '3000.00', 'user', '0775920300', 'PayPal', '2024-05-27'),
(58, 'Cristal Bread', '2500.00', 'user', '0775920300', 'PayPal', '2024-05-27'),
(59, 'Cap cakes', '500.98', 'user', '0775920300', 'PayPal', '2024-05-27'),
(60, 'Cap cakes', '500.98', 'user', '0775920300', 'PayPal', '2024-05-27'),
(61, 'Cristal Bread', '2500.00', 'user', '0775920300', 'PayPal', '2024-05-27'),
(62, 'Cap cakes', '500.98', 'user', '0775920300', 'PayPal', '2024-05-27'),
(63, 'Cristal Bread', '2500.00', 'user', '0704902004', 'MTN Mobile Money', '2024-05-27'),
(64, 'Milk', '500.00', 'user', '0704902004', 'MTN Mobile Money', '2024-05-27'),
(65, 'Cristal Bread', '2500.00', 'namubiru maluwa', '0701617234', 'Credit Card', '2024-05-27'),
(66, 'Cap cakes', '500.98', 'user', '0704902004', 'MTN Mobile Money', '2024-05-28'),
(67, 'Cristal Bread', '2500.00', 'user', '0704902004', 'MTN Mobile Money', '2024-05-28'),
(68, 'The black cream test', '249999.97', 'user', '0704902004', 'MTN Mobile Money', '2024-05-28'),
(69, 'Milk Tea', '2000', 'stuart swafa Nt', '07512879', 'Credit Card', '2024-05-28'),
(70, 'Milk', '500', 'stuart swafa Nt', '07512879', 'Credit Card', '2024-05-28'),
(71, 'Cap cakes', '500.98', 'JESSY', '0704902004', 'Credit Card', '2024-05-28'),
(72, 'Cristal Bread', '2500', 'JESSY', '0704902004', 'Credit Card', '2024-05-28'),
(73, 'Cap cakes', '500.98', 'JESSY', '0775920300', 'Credit Card', '2024-05-28'),
(74, 'Cristal Bread', '2500', 'JESSY', '0775920300', 'Credit Card', '2024-05-28'),
(75, 'The black cream test', '249999.97', 'JESSY', '0775920300', 'Credit Card', '2024-05-28'),
(76, 'Cap cakes', '500.98', 'JESSY', '0775920300', 'Credit Card', '2024-05-28'),
(77, 'Cristal Bread', '2500', 'JESSY', '0775920300', 'Credit Card', '2024-05-28'),
(78, 'The black cream test', '249999.97', 'JESSY', '0775920300', 'Credit Card', '2024-05-28'),
(79, 'Cristal Bread', '2500', 'JESSY', '0701617234', 'MTN Mobile Money', '2024-05-28'),
(80, 'Milk Tea', '2000', 'JESSY', '0775920300', 'Credit Card', '2024-05-28'),
(81, 'Milk', '500', 'JESSY', '0775920300', 'Credit Card', '2024-05-28'),
(82, 'Red yummy Berries', '25000.99', 'JESSY', '0775920300', 'Credit Card', '2024-05-28'),
(83, 'Cristal Bread', '2500', 'Innocent', '0704902004', 'Credit Card', '2024-05-28'),
(84, 'The black cream test', '249999.97', 'Innocent', '0704902004', 'Credit Card', '2024-05-28'),
(85, 'swafa', '3000', 'user', '0704902004', 'Credit Card', '2024-05-28'),
(86, 'Cap cakes', '500.98', 'user', '0704902004', 'Credit Card', '2024-05-29'),
(87, 'Cristal Bread', '2500', 'user', '0709227793', 'Credit Card', '2024-05-29');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `image_url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `product_name`, `description`, `price`, `image_url`) VALUES
(18, 'Chocolate Brown', 'A hybrid between a sponge and a butter cake, made with oil instead of butter.', 180500.98, 'bab118db-30c0-4e66-9d0c-df48adf2708e.png'),
(20, 'Sponge Cake ', 'Light and airy, made with eggs, sugar, and flour, sometimes with a small amount of baking powder.', 2500.00, 'R (1).jpeg'),
(21, 'The black cream test', 'An Italian sponge cake made with whole eggs, sugar, and flour, sometimes with melted butter.', 249999.97, 'cake_PNG96919.png'),
(22, ' Berry cake', 'Made with grated carrots, often including nuts and spices like cinnamon and nutmeg.', 250000.99, '29a02c05-ac89-4ef5-8a7b-acae60303494.png'),
(23, 'Cap cakes', 'Moist and dense, with a slightly spiced flavor, typically paired with cream cheese frosting', 2000.00, '73b06ba4-95f8-4c1c-8f5b-ced621229bf8.png'),
(25, 'Sponge Cake', 'Light and airy, made with eggs, sugar, and flour, sometimes with a small amount of baking powder.', 150500.00, 't.png'),
(27, 'classic Beaty ', 'Made with chopped candied or dried fruits, nuts, and spices, and sometimes soaked in spirits.', 250000.00, 'OIP (1).jpeg'),
(28, 'Coffee Cake', 'Moist and tender, with a crumbly topping, sometimes swirled with cinnamon or nuts.', 50000.00, 'b1a87dce-ebe1-4275-ba1e-7fc9a20d50c8.png'),
(29, 'Wedding Butter Cake', 'Moist and flavorful, with a tender crumb, common examples include pound cake and traditional Wedding cake.', 1000000.00, 'cbf79033aa39bd7297bb3071e0d60745.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `email` varchar(100) NOT NULL,
  `user_type` varchar(25) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `user_type`, `password`) VALUES
(8, 'stuart', 'mugisha@wdfug.org', 'user', 'b0baee9d279d34fa1dfd71aadb908c3f'),
(9, 'swafa', 'mugisha@wdfug.org', 'user', '25f9e794323b453885f5181f1b624d0b'),
(10, 'jessy', 'stuartdonsms@gmail.com', 'user', '827ccb0eea8a706c4c34a16891f84e7b'),
(11, 'baby', 'stuartdonsms@gmail.com', 'user', '827ccb0eea8a706c4c34a16891f84e7b'),
(12, 'mark', 'mark@gmail.com', 'user', 'b0baee9d279d34fa1dfd71aadb908c3f'),
(13, 'furah', 'shumbusho@gmail.com', 'user', 'e10adc3949ba59abbe56e057f20f883e'),
(14, 'stuart', 'povog73282@anawalls.com', 'user', 'b0baee9d279d34fa1dfd71aadb908c3f'),
(15, 'stuart', 'mugisha@wdfug.org', 'user', 'b0baee9d279d34fa1dfd71aadb908c3f'),
(16, 'stuart', 'stuartdonsms@gmail.com', 'user', '827ccb0eea8a706c4c34a16891f84e7b'),
(17, 'stuart', 'mark@gmail.com', 'user', '827ccb0eea8a706c4c34a16891f84e7b');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `furstuart`
--
ALTER TABLE `furstuart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `furstuart`
--
ALTER TABLE `furstuart`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=88;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
