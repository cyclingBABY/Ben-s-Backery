Stuart Ntumwa 22/bit/bu/r/1001

Am this is ben's Backery webaplication, and its aim is to allow users buy the products produced by the Backery.

to make it fuction please create the two databases, namely user_db and multi_login,

the multi_login as it name its used by many forms and its handeling most of the submitions from the customer,and its also
used to capture the product details from the admin side like the images,product name,price as set by the admin.

on the other hand the  user_db is used for loging data and registration data of the admin and user... making the website 
have two dashboards.

the admin and the user sides... 

the multi_login has many tables namely,
feedback,---for the contact us
furstuart,--submitions
orders,--orders
product,--products
users..users list


the user_db has one tables
user_info..


now the passwords used

admim   email         =   admim@gmail.com
        password      =   admim


user                  =  user@gmail.com
password              =   user  

STUART NTUMWA 22/BIT/BU/R/1001, 