<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>ORDERS</title>
</head>
<body class="welcome_2">
   <H1><span>Order places successfully</span></H1><br>
   <a href="user.php" class="btn">Back to home</a>
</body>
</html>
<style>
    body.welcome_2 {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
    font-family: Arial, sans-serif;
    background-color: transparent;
    text-align: center;
}



body.welcome_2 a.btn:hover {
    background-color: #0056b3;
}

</style>